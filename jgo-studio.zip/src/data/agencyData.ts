export const BRAND = {
  name: "JGO Studio",
  tagline: "Sua ideia, nosso foco!",
  whatsappDisplay: "(35) 9805-4089",
  whatsappNumber: "553598054089",
  instagramHandle: "@jgostudio",
  instagramUrl: "https://instagram.com/jgostudio",
} as const;

export function buildWhatsAppUrl(message: string): string {
  return `https://wa.me/${BRAND.whatsappNumber}?text=${encodeURIComponent(message)}`;
}

export const DEFAULT_WHATSAPP_MESSAGE =
  "Olá, JGO Studio! Gostaria de solicitar uma análise e orçamento para o meu site.";

export const HERO_METRICS = [
  {
    value: "1 dia útil",
    label: "Prazo de entrega ágil para colocar sua empresa no ar",
  },
  {
    value: "+100",
    label: "Sites ativos desenvolvidos para negócios reais",
  },
  {
    value: "7 meses",
    label: "De mercado entregando estrutura digital sob medida",
  },
  {
    value: "100% humano",
    label: "Atendimento direto com especialista, sem robôs",
  },
] as const;

export const DIFFERENTIALS = [
  {
    number: "01",
    title: "Entrega em 1 dia útil",
    description:
      "Estrutura enxuta e processo validado para publicar projetos essenciais em até 24 horas úteis após o envio do material.",
  },
  {
    number: "02",
    title: "Melhor custo-benefício",
    description:
      "Acabamento de alto padrão com investimento realista, desenhado especialmente para o orçamento de pequenas empresas e MEI.",
  },
  {
    number: "03",
    title: "Atendimento humano",
    description:
      "Conversa direta pelo WhatsApp com quem projeta e publica o seu site, sem filas de atendimento ou respostas automáticas.",
  },
  {
    number: "04",
    title: "+100 sites no ar",
    description:
      "Experiência comprovada em diversos nichos: prestadores de serviço, comércios locais, clínicas, consultorias e lojas virtuais.",
  },
] as const;

export type ServiceCategory = "todos" | "presenca" | "conversao" | "evolucao";

export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  category: Exclude<ServiceCategory, "todos">;
  categoryLabel: string;
  summary: string;
  deliverable: string;
  featured?: boolean;
  whatsappMessage: string;
}

export const SERVICES: ServiceItem[] = [
  {
    id: "sites-institucionais",
    number: "01",
    title: "Sites institucionais",
    category: "presenca",
    categoryLabel: "Presença e Autoridade",
    summary:
      "Apresente sua empresa com credibilidade, história, portfólio e canais de atendimento integrados para transmitir confiança imediata.",
    deliverable: "Multi-páginas, mapa, formulário e WhatsApp",
    featured: true,
    whatsappMessage:
      "Olá, JGO Studio! Tenho interesse em um Site Institucional para minha empresa.",
  },
  {
    id: "landing-pages",
    number: "02",
    title: "Landing pages",
    category: "conversao",
    categoryLabel: "Vendas e Conversão",
    summary:
      "Páginas focadas em um único produto, serviço ou campanha de tráfego pago, estruturadas para conduzir o visitante direto ao contato.",
    deliverable: "Copy persuasiva, provas sociais e CTA direto",
    featured: true,
    whatsappMessage:
      "Olá, JGO Studio! Quero solicitar orçamento para uma Landing Page de alta conversão.",
  },
  {
    id: "lojas-virtuais",
    number: "03",
    title: "Lojas virtuais",
    category: "conversao",
    categoryLabel: "E-Commerce",
    summary:
      "Catálogo organizado, variações de produtos, cálculo de frete e pagamento seguro para vender seus produtos 24 horas por dia.",
    deliverable: "Painel de pedidos, Pix, cartão e frete",
    whatsappMessage:
      "Olá, JGO Studio! Gostaria de criar uma Loja Virtual para meu negócio.",
  },
  {
    id: "sites-one-page",
    number: "04",
    title: "Sites one-page",
    category: "presenca",
    categoryLabel: "Presença Ágil",
    summary:
      "Toda a apresentação do seu negócio reunida em uma única página fluida e objetiva, ideal para autônomos e MEI.",
    deliverable: "Navegação por seções e entrega em 1 dia útil",
    whatsappMessage:
      "Olá, JGO Studio! Quero saber mais sobre o Site One-Page com entrega em 1 dia útil.",
  },
  {
    id: "paginas-de-captura",
    number: "05",
    title: "Páginas de captura",
    category: "conversao",
    categoryLabel: "Geração de Leads",
    summary:
      "Estrutura enxuta desenhada para captar contatos qualificados, agendamentos ou inscrições com taxa máxima de preenchimento.",
    deliverable: "Formulário otimizado e integração imediata",
    whatsappMessage:
      "Olá, JGO Studio! Preciso de uma Página de Captura para gerar novos contatos.",
  },
  {
    id: "redesign-de-sites",
    number: "06",
    title: "Redesign de sites",
    category: "evolucao",
    categoryLabel: "Atualização Visual",
    summary:
      "Renovamos sites antigos ou lentos com visual contemporâneo, hierarquia clara e arquitetura atualizada para reconquistar clientes.",
    deliverable: "Novo layout sem perder seu endereço atual",
    whatsappMessage:
      "Olá, JGO Studio! Já tenho um site e gostaria de fazer um Redesign completo.",
  },
  {
    id: "design-responsivo",
    number: "07",
    title: "Design responsivo",
    category: "evolucao",
    categoryLabel: "Experiência Mobile",
    summary:
      "Mais de 80% dos acessos acontecem pelo celular. Cada tela é ajustada manualmente para leitura confortável e toque preciso.",
    deliverable: "Ajuste fino para celular, tablet e desktop",
    whatsappMessage:
      "Olá, JGO Studio! Quero um site com design responsivo impecável no celular.",
  },
  {
    id: "seo-e-manutencao",
    number: "08",
    title: "Otimização para o Google (SEO) e manutenção",
    category: "evolucao",
    categoryLabel: "Performance e Suporte",
    summary:
      "Configuração técnica de títulos, velocidade de carregamento, indexação no Google e atualizações contínuas para manter tudo seguro.",
    deliverable: "SEO técnico, velocidade e suporte mensal",
    whatsappMessage:
      "Olá, JGO Studio! Gostaria de informações sobre SEO para o Google e manutenção de site.",
  },
];

export interface PricingPlan {
  id: string;
  name: string;
  subtitle: string;
  price: string;
  paymentNote: string;
  delivery: string;
  highlighted?: boolean;
  highlightLabel?: string;
  features: string[];
  whatsappMessage: string;
}

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: "essencial",
    name: "Essencial One-Page",
    subtitle: "Para MEI e profissionais que precisam marcar presença rápida e profissional.",
    price: "R$ 300",
    paymentNote: "Pagamento único ou parcelado",
    delivery: "Entrega em 1 dia útil",
    features: [
      "Site One-Page ou Landing Page sob medida",
      "Design responsivo para celular e computador",
      "Botão direto e formulário para WhatsApp",
      "Configuração básica para o Google (SEO)",
      "Atendimento humano na publicação",
    ],
    whatsappMessage:
      "Olá, JGO Studio! Quero contratar o plano Essencial One-Page (R$ 300) com entrega em 1 dia útil.",
  },
  {
    id: "institucional",
    name: "Institucional Pro",
    subtitle: "Ideal para pequenas empresas que buscam autoridade e captação constante.",
    price: "R$ 700",
    paymentNote: "Melhor custo-benefício",
    delivery: "Entrega em até 3 dias úteis",
    highlighted: true,
    highlightLabel: "Mais escolhido",
    features: [
      "Site Institucional completo (até 5 páginas)",
      "Identidade visual refinada e exclusiva",
      "Página de captura ou seção de orçamento",
      "Otimização avançada para o Google (SEO)",
      "Integração com Instagram, Google Maps e Pixel",
      "30 dias de manutenção e ajustes inclusos",
    ],
    whatsappMessage:
      "Olá, JGO Studio! Tenho interesse no plano Institucional Pro (R$ 700) para minha empresa.",
  },
  {
    id: "ecommerce",
    name: "Loja Virtual",
    subtitle: "Estrutura completa para vender produtos online com autonomia e segurança.",
    price: "R$ 1.490",
    paymentNote: "Sem comissão por venda",
    delivery: "Entrega em até 5 dias úteis",
    features: [
      "Catálogo profissional de produtos e categorias",
      "Checkout integrado (Pix, cartão e boleto)",
      "Cálculo automático de frete (Correios/envio)",
      "Design responsivo focado em compras no celular",
      "Treinamento rápido para cadastrar novos itens",
    ],
    whatsappMessage:
      "Olá, JGO Studio! Gostaria de solicitar análise para o plano Loja Virtual (R$ 1.490).",
  },
];

export const CASE_STUDIES = [
  {
    client: "Clínica Odontológica Vale Verde",
    segment: "Saúde e Estética · Sul de Minas",
    result: "+140% em agendamentos pelo WhatsApp em 60 dias",
    summary:
      "Substituição de página antiga por site institucional responsivo com agendamento direto em um toque.",
  },
  {
    client: "Ateliê Nóbrega Couros",
    segment: "Comércio Local · MEI",
    result: "Primeiras 48 vendas online nos 30 dias iniciais",
    summary:
      "Estruturação de loja virtual enxuta integrada ao Instagram @jgostudio e pagamento via Pix.",
  },
  {
    client: "Viana & Barros Contabilidade",
    segment: "Serviços Empresariais · B2B",
    result: "Site publicado em 1 dia útil com 1ª página local no Google",
    summary:
      "Landing page de captura voltada para abertura de MEI e regularização fiscal com SEO local.",
  },
] as const;

export const FAQ_ITEMS = [
  {
    id: "prazo",
    question: "Como funciona a entrega em 1 dia útil?",
    answer:
      "Após alinharmos seu segmento, textos principais e logotipo pelo WhatsApp, nossa equipe inicia a produção imediatamente. Projetos One-Page e Landing Pages são entregues no ar em 1 dia útil para aprovação e publicação.",
  },
  {
    id: "dominio-hospedagem",
    question: "Preciso já ter domínio e hospedagem contratados?",
    answer:
      "Não é obrigatório ter tudo pronto antes de falar conosco. Se você ainda não possui domínio (.com.br) ou hospedagem, orientamos passo a passo na contratação em seu próprio nome para que você tenha 100% de propriedade.",
  },
  {
    id: "alteracoes",
    question: "Posso solicitar ajustes depois que o site ficar pronto?",
    answer:
      "Sim. Todo projeto passa por uma etapa de revisão humana junto com você antes da publicação final, e oferecemos planos acessíveis de manutenção contínua sempre que precisar atualizar fotos, preços ou serviços.",
  },
  {
    id: "pagamento",
    question: "Como funciona a análise gratuita e o pagamento?",
    answer:
      "Você entra em contato pelo WhatsApp ou formulário, analisamos o seu negócio sem compromisso e indicamos o formato ideal. O investimento é transparente, com condições facilitadas para pequenas empresas e MEI.",
  },
] as const;
