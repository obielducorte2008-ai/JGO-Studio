import { MessageCircle } from "lucide-react";
import {
  DEFAULT_WHATSAPP_MESSAGE,
  buildWhatsAppUrl,
} from "@/src/data/agencyData";

export function FloatingWhatsApp() {
  const whatsappUrl = buildWhatsAppUrl(DEFAULT_WHATSAPP_MESSAGE);

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Solicitar análise e orçamento no WhatsApp"
      className="fixed bottom-4 right-4 z-50 inline-flex h-12 items-center gap-2.5 rounded-full bg-whatsapp px-5 text-sm font-semibold text-whatsapp-foreground shadow-floating transition-transform duration-200 ease-out hover:-translate-y-0.5 hover:bg-whatsapp-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 sm:bottom-6 sm:right-6"
    >
      <MessageCircle className="h-5 w-5 shrink-0" aria-hidden="true" />
      <span className="whitespace-nowrap">WhatsApp</span>
    </a>
  );
}
