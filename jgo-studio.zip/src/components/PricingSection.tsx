import { Check, MessageCircle } from "lucide-react";
import { Button } from "@/src/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/src/components/ui/accordion";
import { Reveal } from "@/src/components/Reveal";
import {
  FAQ_ITEMS,
  PRICING_PLANS,
  buildWhatsAppUrl,
} from "@/src/data/agencyData";
import { cn } from "@/src/lib/utils";

export function PricingSection() {
  return (
    <section
      id="planos"
      aria-labelledby="pricing-heading"
      className="border-t border-border bg-surface py-20 sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <Reveal className="max-w-2xl space-y-3">
          <p className="text-xs font-medium tracking-wide text-muted-foreground">
            Investimento Transparente
          </p>
          <h2
            id="pricing-heading"
            className="font-display text-3xl font-semibold leading-tight tracking-tight text-foreground sm:text-4xl [text-wrap:balance]"
          >
            Planos claros para colocar seu negócio no ar sem surpresas.
          </h2>
          <p className="text-base leading-relaxed text-muted-foreground">
            Estrutura pensada para o melhor custo-benefício do mercado, com
            escopo definido e acompanhamento humano desde o primeiro contato.
          </p>
        </Reveal>

        {/* Grade de 3 planos */}
        <div className="mt-12 grid items-stretch gap-6 lg:grid-cols-3">
          {PRICING_PLANS.map((plan, index) => {
            const isHighlighted = Boolean(plan.highlighted);

            return (
              <Reveal key={plan.id} delay={index * 0.06} className="h-full">
                <article
                  className={cn(
                    "flex h-full flex-col justify-between rounded-xl border p-7 transition-all duration-200",
                    isHighlighted
                      ? "border-primary bg-gradient-navy text-primary-foreground shadow-elevated"
                      : "border-border bg-card text-card-foreground shadow-card hover:border-border-strong"
                  )}
                >
                  <div>
                    <div className="flex items-center justify-between gap-3 text-xs">
                      <span
                        className={cn(
                          "font-medium",
                          isHighlighted
                            ? "text-obsidian-muted"
                            : "text-muted-foreground"
                        )}
                      >
                        {plan.delivery}
                      </span>
                      {plan.highlightLabel && (
                        <span className="font-semibold text-primary-foreground">
                          {plan.highlightLabel}
                        </span>
                      )}
                    </div>

                    <h3 className="mt-3 font-display text-2xl font-semibold tracking-tight">
                      {plan.name}
                    </h3>

                    <p
                      className={cn(
                        "mt-2 text-sm leading-relaxed",
                        isHighlighted
                          ? "text-obsidian-muted"
                          : "text-muted-foreground"
                      )}
                    >
                      {plan.subtitle}
                    </p>

                    <div
                      className={cn(
                        "mt-6 border-y py-5",
                        isHighlighted
                          ? "border-obsidian-border"
                          : "border-border"
                      )}
                    >
                      <p className="font-display text-4xl font-semibold tracking-tight tabular-nums">
                        {plan.price}
                      </p>
                      <p
                        className={cn(
                          "mt-1 text-xs",
                          isHighlighted
                            ? "text-obsidian-muted"
                            : "text-muted-foreground"
                        )}
                      >
                        {plan.paymentNote}
                      </p>
                    </div>

                    <ul className="mt-6 space-y-3">
                      {plan.features.map((feature) => (
                        <li
                          key={feature}
                          className="flex items-start gap-2.5 text-sm leading-snug"
                        >
                          <Check
                            className={cn(
                              "mt-0.5 h-4 w-4 shrink-0",
                              isHighlighted
                                ? "text-primary-foreground"
                                : "text-primary"
                            )}
                            aria-hidden="true"
                          />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="mt-8 pt-2">
                    <Button
                      asChild
                      size="lg"
                      variant={isHighlighted ? "secondary" : "default"}
                      className="h-auto min-h-12 w-full max-w-full whitespace-normal px-5 py-3 text-center sm:whitespace-nowrap"
                    >
                      <a
                        href={buildWhatsAppUrl(plan.whatsappMessage)}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <MessageCircle className="h-4 w-4" aria-hidden="true" />
                        <span>Solicitar este plano no WhatsApp</span>
                      </a>
                    </Button>
                  </div>
                </article>
              </Reveal>
            );
          })}
        </div>

        {/* Perguntas frequentes adjacentes aos planos */}
        <Reveal delay={0.12} className="mt-16 rounded-xl border border-border bg-card p-6 shadow-card sm:p-10">
          <div className="grid gap-8 lg:grid-cols-12">
            <div className="space-y-2 lg:col-span-5">
              <p className="text-xs font-medium text-muted-foreground">
                Dúvidas Frequentes
              </p>
              <h3 className="font-display text-2xl font-semibold tracking-tight text-foreground">
                Transparência antes mesmo de fechar o projeto
              </h3>
              <p className="text-sm leading-relaxed text-muted-foreground">
                Se sua empresa precisa de algo personalizado, nossa equipe monta
                uma proposta sob medida pelo WhatsApp sem compromisso.
              </p>
            </div>

            <div className="lg:col-span-7">
              <Accordion type="single" collapsible defaultValue="prazo">
                {FAQ_ITEMS.map((item) => (
                  <AccordionItem key={item.id} value={item.id}>
                    <AccordionTrigger>{item.question}</AccordionTrigger>
                    <AccordionContent>{item.answer}</AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
