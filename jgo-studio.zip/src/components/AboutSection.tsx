import { ArrowUpRight } from "lucide-react";
import { Button } from "@/src/components/ui/button";
import { ResilientImage } from "@/src/components/ResilientImage";
import { Reveal } from "@/src/components/Reveal";
import {
  BRAND,
  CASE_STUDIES,
  DIFFERENTIALS,
  buildWhatsAppUrl,
} from "@/src/data/agencyData";

export function AboutSection() {
  const whatsappHref = buildWhatsAppUrl(
    "Olá, JGO Studio! Conheci a história da agência e quero conversar sobre o site do meu negócio."
  );

  return (
    <section
      id="sobre"
      aria-labelledby="about-heading"
      className="bg-gradient-obsidian py-20 text-obsidian-foreground sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-stretch gap-12 lg:grid-cols-12">
          {/* Fotografia editorial da equipe/processo */}
          <Reveal className="lg:col-span-5">
            <div className="h-full overflow-hidden rounded-xl border border-obsidian-border bg-obsidian-surface shadow-elevated">
              <div className="aspect-[4/3] lg:h-full lg:aspect-auto">
                <ResilientImage
                  src="/src/assets/images/about_jgo_craft_1795666188006.jpg"
                  alt="Especialistas da JGO Studio estruturando layout responsivo e tipografia para site empresarial"
                  fallbackTitle="Processo JGO Studio"
                />
              </div>
            </div>
          </Reveal>

          {/* Texto institucional e 4 diferenciais competitivos */}
          <Reveal delay={0.08} className="flex flex-col justify-between gap-8 lg:col-span-7">
            <div className="space-y-5">
              <p className="text-xs font-medium tracking-wide text-obsidian-muted">
                Sobre a {BRAND.name}{" "}
                <span aria-hidden="true" className="mx-1.5">
                  ·
                </span>{" "}
                Quem Somos
              </p>

              <h2
                id="about-heading"
                className="font-display text-3xl font-semibold leading-tight tracking-tight text-obsidian-foreground sm:text-4xl [text-wrap:balance]"
              >
                Transformamos ideias em plataformas digitais rápidas, intuitivas
                e construídas para vender.
              </h2>

              <p className="text-base leading-relaxed text-obsidian-muted">
                Há 7 meses no mercado, somos uma agência focada na criação de
                sites modernos, responsivos e estratégicos para empresas de
                diversos segmentos. Nossa especialidade é transformar ideias em
                plataformas digitais rápidas e intuitivas, adaptadas à
                identidade e às necessidades de cada negócio.
              </p>

              <p className="text-base leading-relaxed text-obsidian-muted">
                Nosso propósito é impulsionar a presença online de marcas e
                empreendedores, entregando soluções acessíveis que geram
                autoridade e atraem clientes reais — com atenção especial a
                pequenas empresas e MEI.
              </p>
            </div>

            {/* Grade 2x2 de diferenciais competitivos */}
            <div className="grid gap-4 sm:grid-cols-2">
              {DIFFERENTIALS.map((item) => (
                <div
                  key={item.number}
                  className="rounded-lg border border-obsidian-border bg-obsidian-surface/70 p-5 transition-colors duration-200 hover:bg-obsidian-surface"
                >
                  <p className="text-xs font-medium text-obsidian-muted tabular-nums">
                    {item.number}.
                  </p>
                  <h3 className="mt-1.5 font-display text-lg font-semibold text-obsidian-foreground">
                    {item.title}
                  </h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-obsidian-muted">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>

            <div className="pt-1">
              <Button asChild variant="outlineOnDark" size="lg">
                <a
                  href={whatsappHref}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <span>Falar diretamente com nossa equipe</span>
                  <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                </a>
              </Button>
            </div>
          </Reveal>
        </div>

        {/* Provas adjacentes: resultados reais de empresas atendidas */}
        <Reveal delay={0.12} className="mt-16 border-t border-obsidian-border pt-12">
          <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div>
              <p className="text-xs font-medium text-obsidian-muted">
                Resultados Comprovados
              </p>
              <h3 className="mt-1 font-display text-2xl font-semibold tracking-tight text-obsidian-foreground">
                Impacto direto nos negócios que já estão no ar
              </h3>
            </div>
            <p className="text-sm text-obsidian-muted">
              Mais de 100 projetos publicados para diversos segmentos
            </p>
          </div>

          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {CASE_STUDIES.map((item) => (
              <div
                key={item.client}
                className="flex flex-col justify-between gap-4 rounded-xl border border-obsidian-border bg-obsidian-surface/60 p-6"
              >
                <div className="space-y-2.5">
                  <p className="text-xs text-obsidian-muted">{item.segment}</p>
                  <p className="font-display text-lg font-semibold leading-snug text-obsidian-foreground">
                    {item.result}
                  </p>
                  <p className="text-sm leading-relaxed text-obsidian-muted">
                    {item.summary}
                  </p>
                </div>
                <p className="border-t border-obsidian-border pt-3 text-xs font-medium text-obsidian-foreground">
                  {item.client}
                </p>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
