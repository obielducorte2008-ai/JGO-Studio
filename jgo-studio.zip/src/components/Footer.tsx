import { Instagram, MessageCircle } from "lucide-react";
import {
  BRAND,
  DEFAULT_WHATSAPP_MESSAGE,
  buildWhatsAppUrl,
} from "@/src/data/agencyData";

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid gap-10 border-b border-obsidian-border pb-10 md:grid-cols-12">
          <div className="space-y-3 md:col-span-5">
            <a
              href="#inicio"
              className="font-display text-2xl font-semibold tracking-tight text-primary-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-foreground rounded-sm"
            >
              {BRAND.name}
            </a>
            <p className="text-sm font-medium text-obsidian-muted">
              {BRAND.tagline}
            </p>
            <p className="max-w-sm text-sm leading-relaxed text-obsidian-muted">
              Criação de sites institucionais, landing pages e lojas virtuais de
              alto padrão para pequenas empresas e MEI.
            </p>
          </div>

          <div className="space-y-3 md:col-span-3">
            <p className="text-xs font-semibold tracking-wide text-obsidian-muted">
              Navegação
            </p>
            <ul className="space-y-2.5 text-sm">
              <li>
                <a
                  href="#inicio"
                  className="text-primary-foreground/90 transition-colors hover:text-primary-foreground hover:underline underline-offset-4"
                >
                  Início
                </a>
              </li>
              <li>
                <a
                  href="#sobre"
                  className="text-primary-foreground/90 transition-colors hover:text-primary-foreground hover:underline underline-offset-4"
                >
                  Sobre a agência
                </a>
              </li>
              <li>
                <a
                  href="#servicos"
                  className="text-primary-foreground/90 transition-colors hover:text-primary-foreground hover:underline underline-offset-4"
                >
                  Serviços
                </a>
              </li>
              <li>
                <a
                  href="#planos"
                  className="text-primary-foreground/90 transition-colors hover:text-primary-foreground hover:underline underline-offset-4"
                >
                  Preços e Planos
                </a>
              </li>
              <li>
                <a
                  href="#contato"
                  className="text-primary-foreground/90 transition-colors hover:text-primary-foreground hover:underline underline-offset-4"
                >
                  Formulário de Contato
                </a>
              </li>
            </ul>
          </div>

          <div className="space-y-3 md:col-span-4">
            <p className="text-xs font-semibold tracking-wide text-obsidian-muted">
              Atendimento Direto
            </p>
            <ul className="space-y-3 text-sm">
              <li>
                <a
                  href={buildWhatsAppUrl(DEFAULT_WHATSAPP_MESSAGE)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-primary-foreground transition-colors hover:underline underline-offset-4 tabular-nums"
                >
                  <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                  <span>WhatsApp: {BRAND.whatsappDisplay}</span>
                </a>
              </li>
              <li>
                <a
                  href={BRAND.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-primary-foreground transition-colors hover:underline underline-offset-4"
                >
                  <Instagram className="h-4 w-4 shrink-0" aria-hidden="true" />
                  <span>Instagram: {BRAND.instagramHandle}</span>
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col items-start justify-between gap-4 pt-6 text-xs text-obsidian-muted sm:flex-row sm:items-center">
          <p>
            © {currentYear} {BRAND.name}. Todos os direitos reservados.
          </p>
          <p>+100 sites publicados · Entrega em 1 dia útil</p>
        </div>
      </div>
    </footer>
  );
}
