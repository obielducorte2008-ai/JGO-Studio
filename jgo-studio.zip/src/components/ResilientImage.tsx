import { useState } from "react";
import { ImageOff } from "lucide-react";
import { cn } from "@/src/lib/utils";

interface ResilientImageProps {
  src: string;
  alt: string;
  className?: string;
  fallbackTitle?: string;
  aspectClassName?: string;
}

export function ResilientImage({
  src,
  alt,
  className,
  fallbackTitle = "JGO Studio",
  aspectClassName,
}: ResilientImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={cn(
          "flex flex-col items-center justify-center gap-3 bg-gradient-navy p-8 text-center text-primary-foreground",
          aspectClassName,
          className
        )}
      >
        <div className="flex h-12 w-12 items-center justify-center rounded-full border border-obsidian-border">
          <ImageOff className="h-5 w-5 text-obsidian-muted" aria-hidden="true" />
        </div>
        <div className="space-y-1">
          <p className="font-display text-lg font-semibold tracking-tight">
            {fallbackTitle}
          </p>
          <p className="text-xs text-obsidian-muted">
            Apresentação digital sob medida
          </p>
        </div>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={cn("block h-full w-full object-cover", className)}
    />
  );
}
