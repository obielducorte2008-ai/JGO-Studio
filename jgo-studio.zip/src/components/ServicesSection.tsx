import { useState } from "react";
import { ArrowUpRight } from "lucide-react";
import {
  Tabs,
  TabsList,
  TabsTrigger,
} from "@/src/components/ui/tabs";
import { ResilientImage } from "@/src/components/ResilientImage";
import { Reveal } from "@/src/components/Reveal";
import {
  SERVICES,
  type ServiceCategory,
  buildWhatsAppUrl,
} from "@/src/data/agencyData";

const CATEGORY_TABS: { value: ServiceCategory; label: string }[] = [
  { value: "todos", label: "Todos os serviços (8)" },
  { value: "presenca", label: "Presença e Autoridade" },
  { value: "conversao", label: "Vendas e Captura" },
  { value: "evolucao", label: "Redesign e SEO" },
];

export function ServicesSection() {
  const [activeCategory, setActiveCategory] =
    useState<ServiceCategory>("todos");

  const filteredServices =
    activeCategory === "todos"
      ? SERVICES
      : SERVICES.filter((service) => service.category === activeCategory);

  return (
    <section
      id="servicos"
      aria-labelledby="services-heading"
      className="bg-background py-20 sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        {/* Cabeçalho da seção + Controle de filtro */}
        <Reveal className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div className="max-w-2xl space-y-3">
            <p className="text-xs font-medium tracking-wide text-muted-foreground">
              Soluções Sob Medida
            </p>
            <h2
              id="services-heading"
              className="font-display text-3xl font-semibold leading-tight tracking-tight text-foreground sm:text-4xl [text-wrap:balance]"
            >
              Tudo o que sua empresa precisa para se destacar e vender online.
            </h2>
            <p className="text-base leading-relaxed text-muted-foreground">
              Estruturamos desde páginas rápidas para campanhas até lojas
              virtuais completas, sempre com foco em clareza, velocidade e
              conversão no WhatsApp.
            </p>
          </div>

          <Tabs
            value={activeCategory}
            onValueChange={(value) =>
              setActiveCategory(value as ServiceCategory)
            }
          >
            <TabsList aria-label="Filtrar serviços por categoria">
              {CATEGORY_TABS.map((tab) => (
                <TabsTrigger key={tab.value} value={tab.value}>
                  {tab.label}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </Reveal>

        {/* Grade assimétrica Bento para os 8 serviços */}
        <div className="mt-12 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
          {filteredServices.map((service) => {
            const isWide =
              activeCategory === "todos" && service.featured === true;

            return (
              <Reveal
                key={service.id}
                className={isWide ? "md:col-span-2 lg:col-span-1" : ""}
              >
                <article className="group flex h-full flex-col justify-between rounded-xl border border-border bg-gradient-card-subtle p-6 shadow-card transition-all duration-200 hover:-translate-y-0.5 hover:border-border-strong hover:shadow-elevated">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-3 text-xs text-muted-foreground">
                      <span className="font-medium text-primary tabular-nums">
                        {service.number}.
                      </span>
                      <span>{service.categoryLabel}</span>
                    </div>

                    <h3 className="font-display text-xl font-semibold leading-snug text-foreground">
                      {service.title}
                    </h3>

                    <p className="text-sm leading-relaxed text-muted-foreground">
                      {service.summary}
                    </p>
                  </div>

                  <div className="mt-6 space-y-4 border-t border-border pt-4">
                    <p className="text-xs font-medium text-foreground">
                      Inclui: {service.deliverable}
                    </p>

                    <a
                      href={buildWhatsAppUrl(service.whatsappMessage)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary transition-colors duration-200 hover:text-primary-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
                    >
                      <span>Solicitar análise no WhatsApp</span>
                      <ArrowUpRight
                        className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                        aria-hidden="true"
                      />
                    </a>
                  </div>
                </article>
              </Reveal>
            );
          })}
        </div>

        {/* Vitrine visual de projetos entregues */}
        <Reveal delay={0.1} className="mt-14 grid gap-6 lg:grid-cols-12">
          <div className="overflow-hidden rounded-xl border border-border bg-card shadow-card lg:col-span-7">
            <div className="aspect-[16/9] overflow-hidden">
              <ResilientImage
                src="/src/assets/images/showcase_corporate_site_1795666188229.jpg"
                alt="Exemplo de site institucional responsivo exibido em monitor desktop e smartphone sobre base azul marinho"
                fallbackTitle="Site Institucional"
              />
            </div>
            <div className="flex flex-col justify-between gap-2 p-6 sm:flex-row sm:items-center">
              <div>
                <p className="text-xs text-muted-foreground">
                  Sites Institucionais e One-Page
                </p>
                <p className="font-display text-lg font-semibold text-foreground">
                  Autoridade imediata no computador e no celular
                </p>
              </div>
              <a
                href={buildWhatsAppUrl(
                  "Olá, JGO Studio! Quero um site institucional elegante como os do portfólio."
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:underline whitespace-nowrap shrink-0"
              >
                <span>Orçar projeto</span>
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>

          <div className="overflow-hidden rounded-xl border border-border bg-card shadow-card lg:col-span-5">
            <div className="aspect-[4/3] overflow-hidden lg:aspect-[16/11]">
              <ResilientImage
                src="/src/assets/images/showcase_ecommerce_brand_1795666189174.jpg"
                alt="Vitrine de loja virtual profissional em notebook e celular com interface limpa em branco e azul marinho"
                fallbackTitle="Loja Virtual"
              />
            </div>
            <div className="flex flex-col justify-between gap-2 p-6 sm:flex-row sm:items-center">
              <div>
                <p className="text-xs text-muted-foreground">
                  Lojas Virtuais e Páginas de Captura
                </p>
                <p className="font-display text-lg font-semibold text-foreground">
                  Catálogo claro para vender sem atrito
                </p>
              </div>
              <a
                href={buildWhatsAppUrl(
                  "Olá, JGO Studio! Gostaria de criar uma loja virtual profissional."
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:underline whitespace-nowrap shrink-0"
              >
                <span>Criar loja</span>
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
