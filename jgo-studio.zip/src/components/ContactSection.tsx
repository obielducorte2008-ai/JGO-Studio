import { useState, type FormEvent } from "react";
import { CheckCircle2, Copy, Instagram, MessageCircle, Send } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/src/components/ui/button";
import { Input } from "@/src/components/ui/input";
import { Label } from "@/src/components/ui/label";
import { Textarea } from "@/src/components/ui/textarea";
import { Reveal } from "@/src/components/Reveal";
import { BRAND, buildWhatsAppUrl } from "@/src/data/agencyData";

const PROJECT_OPTIONS = [
  "Site Institucional",
  "Landing Page",
  "Loja Virtual",
  "Site One-Page (Entrega 1 dia útil)",
  "Página de Captura",
  "Redesign de Site / SEO",
] as const;

interface FormState {
  name: string;
  business: string;
  phone: string;
  projectType: string;
  details: string;
}

interface FormErrors {
  name?: string;
  business?: string;
  phone?: string;
  details?: string;
}

const INITIAL_FORM: FormState = {
  name: "",
  business: "",
  phone: "",
  projectType: PROJECT_OPTIONS[0],
  details: "",
};

function formatPhoneInput(value: string): string {
  const digits = value.replace(/\D/g, "").slice(0, 11);
  if (digits.length <= 2) return digits;
  if (digits.length <= 6) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
  if (digits.length <= 10) {
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
  }
  return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
}

export function ContactSection() {
  const [form, setForm] = useState<FormState>(INITIAL_FORM);
  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedBriefing, setSubmittedBriefing] = useState<string | null>(
    null
  );

  function validate(): boolean {
    const nextErrors: FormErrors = {};

    if (form.name.trim().length < 2) {
      nextErrors.name = "Informe seu nome para o atendimento.";
    }
    if (form.business.trim().length < 2) {
      nextErrors.business = "Informe o nome da sua empresa ou segmento.";
    }
    const phoneDigits = form.phone.replace(/\D/g, "");
    if (phoneDigits.length < 10) {
      nextErrors.phone = "Digite um WhatsApp válido com DDD (ex: 35 9805-4089).";
    }
    if (form.details.trim().length < 10) {
      nextErrors.details =
        "Conte brevemente o que você deseja no site (mínimo 10 caracteres).";
    }

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  }

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!validate()) {
      toast.error("Verifique os campos destacados antes de enviar.");
      return;
    }

    const summary = [
      `Olá, JGO Studio! Solicito análise e orçamento:`,
      `• Nome: ${form.name.trim()}`,
      `• Empresa/Segmento: ${form.business.trim()}`,
      `• WhatsApp: ${form.phone.trim()}`,
      `• Tipo de projeto: ${form.projectType}`,
      `• Detalhes: ${form.details.trim()}`,
    ].join("\n");

    setSubmittedBriefing(summary);
    toast.success(
      "Briefing preparado com sucesso. Clique abaixo para enviar no WhatsApp."
    );
  }

  async function handleCopySummary() {
    if (!submittedBriefing) return;
    try {
      await navigator.clipboard.writeText(submittedBriefing);
      toast.success("Resumo copiado para a área de transferência.");
    } catch {
      toast.error("Não foi possível copiar automaticamente.");
    }
  }

  return (
    <section
      id="contato"
      aria-labelledby="contact-heading"
      className="border-t border-border bg-background py-20 sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-start gap-12 lg:grid-cols-12">
          {/* Coluna esquerda: convite direto + canais oficiais */}
          <Reveal className="space-y-6 lg:col-span-5">
            <div className="space-y-3">
              <p className="text-xs font-medium tracking-wide text-muted-foreground">
                Contato e Análise Gratuita
              </p>
              <h2
                id="contact-heading"
                className="font-display text-3xl font-semibold leading-tight tracking-tight text-foreground sm:text-4xl [text-wrap:balance]"
              >
                {BRAND.tagline} Solicite sua proposta sem compromisso.
              </h2>
              <p className="text-base leading-relaxed text-muted-foreground">
                Preencha o formulário ao lado ou fale diretamente no nosso
                WhatsApp. Respondemos com atendimento humano, análise do seu
                segmento e indicação do melhor formato para o seu negócio.
              </p>
            </div>

            <div className="divide-y divide-border rounded-xl border border-border bg-surface">
              <div className="p-5">
                <p className="text-xs font-medium text-muted-foreground">
                  WhatsApp Comercial
                </p>
                <a
                  href={buildWhatsAppUrl(
                    "Olá, JGO Studio! Gostaria de solicitar uma análise e orçamento."
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-1 inline-flex items-center gap-2 font-display text-xl font-semibold text-primary tabular-nums hover:underline"
                >
                  <MessageCircle className="h-4 w-4" aria-hidden="true" />
                  <span>{BRAND.whatsappDisplay}</span>
                </a>
                <p className="mt-1 text-xs text-muted-foreground">
                  Resposta rápida em horário comercial
                </p>
              </div>

              <div className="p-5">
                <p className="text-xs font-medium text-muted-foreground">
                  Instagram Oficial
                </p>
                <a
                  href={BRAND.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-1 inline-flex items-center gap-2 font-display text-xl font-semibold text-primary hover:underline"
                >
                  <Instagram className="h-4 w-4" aria-hidden="true" />
                  <span>{BRAND.instagramHandle}</span>
                </a>
                <p className="mt-1 text-xs text-muted-foreground">
                  Bastidores, projetos recentes e dicas para MEI
                </p>
              </div>
            </div>
          </Reveal>

          {/* Coluna direita: Formulário validado com envio direto ao WhatsApp */}
          <Reveal delay={0.08} className="lg:col-span-7">
            <div className="rounded-xl border border-border bg-card p-6 shadow-card sm:p-8">
              {submittedBriefing ? (
                <div className="space-y-6" role="status" aria-live="polite">
                  <div className="flex items-start gap-3">
                    <CheckCircle2
                      className="mt-0.5 h-6 w-6 shrink-0 text-success"
                      aria-hidden="true"
                    />
                    <div className="space-y-1">
                      <h3 className="font-display text-2xl font-semibold text-foreground">
                        Briefing pronto para análise
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        Revise seus dados abaixo e conclua o envio diretamente
                        no WhatsApp da {BRAND.name}.
                      </p>
                    </div>
                  </div>

                  <pre className="whitespace-pre-wrap rounded-lg border border-border bg-surface p-4 font-sans text-sm leading-relaxed text-foreground">
                    {submittedBriefing}
                  </pre>

                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                    <Button asChild size="lg" className="w-full sm:w-auto">
                      <a
                        href={buildWhatsAppUrl(submittedBriefing)}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <MessageCircle className="h-4 w-4" aria-hidden="true" />
                        <span>Enviar agora no WhatsApp</span>
                      </a>
                    </Button>

                    <Button
                      type="button"
                      variant="outline"
                      size="lg"
                      onClick={handleCopySummary}
                      className="w-full sm:w-auto"
                    >
                      <Copy className="h-4 w-4" aria-hidden="true" />
                      <span>Copiar resumo</span>
                    </Button>

                    <Button
                      type="button"
                      variant="ghost"
                      onClick={() => setSubmittedBriefing(null)}
                      className="w-full sm:w-auto"
                    >
                      Editar dados
                    </Button>
                  </div>
                </div>
              ) : (
                <form
                  onSubmit={handleSubmit}
                  noValidate
                  className="space-y-5"
                >
                  <div className="grid gap-5 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="contact-name">Seu nome</Label>
                      <Input
                        id="contact-name"
                        name="name"
                        autoComplete="name"
                        placeholder="Ex: Mariana Almeida"
                        value={form.name}
                        onChange={(e) => {
                          setForm((prev) => ({ ...prev, name: e.target.value }));
                          if (errors.name) {
                            setErrors((prev) => ({ ...prev, name: undefined }));
                          }
                        }}
                        aria-invalid={Boolean(errors.name)}
                        aria-describedby={
                          errors.name ? "contact-name-error" : undefined
                        }
                      />
                      {errors.name && (
                        <p
                          id="contact-name-error"
                          className="text-xs font-medium text-destructive"
                        >
                          {errors.name}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="contact-business">
                        Empresa ou segmento
                      </Label>
                      <Input
                        id="contact-business"
                        name="business"
                        placeholder="Ex: Barbearia, Escritório, Loja"
                        value={form.business}
                        onChange={(e) => {
                          setForm((prev) => ({
                            ...prev,
                            business: e.target.value,
                          }));
                          if (errors.business) {
                            setErrors((prev) => ({
                              ...prev,
                              business: undefined,
                            }));
                          }
                        }}
                        aria-invalid={Boolean(errors.business)}
                        aria-describedby={
                          errors.business ? "contact-business-error" : undefined
                        }
                      />
                      {errors.business && (
                        <p
                          id="contact-business-error"
                          className="text-xs font-medium text-destructive"
                        >
                          {errors.business}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="grid gap-5 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="contact-phone">WhatsApp com DDD</Label>
                      <Input
                        id="contact-phone"
                        name="phone"
                        type="tel"
                        autoComplete="tel"
                        placeholder="(35) 99999-9999"
                        value={form.phone}
                        onChange={(e) => {
                          const formatted = formatPhoneInput(e.target.value);
                          setForm((prev) => ({ ...prev, phone: formatted }));
                          if (errors.phone) {
                            setErrors((prev) => ({
                              ...prev,
                              phone: undefined,
                            }));
                          }
                        }}
                        aria-invalid={Boolean(errors.phone)}
                        aria-describedby={
                          errors.phone ? "contact-phone-error" : undefined
                        }
                      />
                      {errors.phone && (
                        <p
                          id="contact-phone-error"
                          className="text-xs font-medium text-destructive"
                        >
                          {errors.phone}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="contact-project">Tipo de projeto</Label>
                      <select
                        id="contact-project"
                        name="projectType"
                        value={form.projectType}
                        onChange={(e) =>
                          setForm((prev) => ({
                            ...prev,
                            projectType: e.target.value,
                          }))
                        }
                        className="flex h-11 w-full rounded-md border border-input bg-background px-3.5 py-2 text-sm text-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:border-primary"
                      >
                        {PROJECT_OPTIONS.map((option) => (
                          <option key={option} value={option}>
                            {option}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="contact-details">
                      Descreva sua ideia ou objetivo
                    </Label>
                    <Textarea
                      id="contact-details"
                      name="details"
                      placeholder="Conte o que sua empresa vende, se já tem site ou domínio e o prazo desejado..."
                      value={form.details}
                      onChange={(e) => {
                        setForm((prev) => ({
                          ...prev,
                          details: e.target.value,
                        }));
                        if (errors.details) {
                          setErrors((prev) => ({
                            ...prev,
                            details: undefined,
                          }));
                        }
                      }}
                      aria-invalid={Boolean(errors.details)}
                      aria-describedby={
                        errors.details ? "contact-details-error" : undefined
                      }
                    />
                    {errors.details && (
                      <p
                        id="contact-details-error"
                        className="text-xs font-medium text-destructive"
                      >
                        {errors.details}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col gap-3 pt-1 sm:flex-row sm:items-center sm:justify-between">
                    <Button type="submit" size="lg" className="w-full sm:w-auto">
                      <Send className="h-4 w-4" aria-hidden="true" />
                      <span>Solicitar análise e orçamento</span>
                    </Button>
                    <p className="text-xs text-muted-foreground">
                      Atendimento direto, sem compromisso.
                    </p>
                  </div>
                </form>
              )}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
