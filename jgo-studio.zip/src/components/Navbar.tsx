import { useState } from "react";
import { Menu, X, Instagram, ArrowUpRight } from "lucide-react";
import { Button } from "@/src/components/ui/button";
import {
  BRAND,
  DEFAULT_WHATSAPP_MESSAGE,
  buildWhatsAppUrl,
} from "@/src/data/agencyData";

const NAV_LINKS = [
  { label: "Sobre", href: "#sobre" },
  { label: "Serviços", href: "#servicos" },
  { label: "Planos", href: "#planos" },
  { label: "Contato", href: "#contato" },
] as const;

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const whatsappHref = buildWhatsAppUrl(DEFAULT_WHATSAPP_MESSAGE);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border bg-background/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-8 px-4 py-3.5 sm:px-6 lg:px-8">
        {/* Zona 1: Marca em linha única */}
        <a
          href="#inicio"
          className="font-display text-xl font-semibold tracking-tight text-primary whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
        >
          {BRAND.name}
        </a>

        {/* Zona 2: Links de navegação concisos em linha única */}
        <nav
          aria-label="Navegação principal"
          className="hidden md:flex items-center gap-7 text-sm font-medium text-muted-foreground"
        >
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="whitespace-nowrap shrink-0 transition-colors duration-200 hover:text-primary underline-offset-4 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
            >
              {link.label}
            </a>
          ))}
          <a
            href={BRAND.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram da JGO Studio (@jgostudio)"
            className="inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 text-primary transition-colors duration-200 hover:text-primary-hover underline-offset-4 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
          >
            <Instagram className="h-4 w-4" aria-hidden="true" />
            <span>{BRAND.instagramHandle}</span>
          </a>
        </nav>

        {/* Zona 3: 1 ação principal */}
        <div className="flex items-center gap-3 shrink-0">
          <Button asChild size="sm" className="hidden sm:inline-flex">
            <a href={whatsappHref} target="_blank" rel="noopener noreferrer">
              <span>Orçamento no WhatsApp</span>
              <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
            </a>
          </Button>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-expanded={mobileOpen}
            aria-controls="mobile-menu"
            aria-label={mobileOpen ? "Fechar menu" : "Abrir menu"}
            className="inline-flex h-11 w-11 items-center justify-center rounded-md border border-border text-foreground transition-colors hover:bg-secondary md:hidden focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring cursor-pointer"
          >
            {mobileOpen ? (
              <X className="h-5 w-5" aria-hidden="true" />
            ) : (
              <Menu className="h-5 w-5" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      {/* Menu Mobile */}
      {mobileOpen && (
        <div
          id="mobile-menu"
          className="border-t border-border bg-background px-4 py-4 md:hidden"
        >
          <nav
            aria-label="Navegação mobile"
            className="flex flex-col gap-1"
          >
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="flex min-h-11 items-center rounded-md px-3 text-base font-medium text-foreground transition-colors hover:bg-secondary"
              >
                {link.label}
              </a>
            ))}
            <a
              href={BRAND.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setMobileOpen(false)}
              className="flex min-h-11 items-center gap-2 rounded-md px-3 text-base font-medium text-primary transition-colors hover:bg-secondary"
            >
              <Instagram className="h-4 w-4" aria-hidden="true" />
              <span>{BRAND.instagramHandle}</span>
            </a>
            <div className="pt-3">
              <Button asChild className="w-full">
                <a
                  href={whatsappHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setMobileOpen(false)}
                >
                  <span>Solicitar orçamento no WhatsApp</span>
                  <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                </a>
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
