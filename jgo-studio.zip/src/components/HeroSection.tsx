import { ArrowRight, MessageCircle } from "lucide-react";
import { Button } from "@/src/components/ui/button";
import { ResilientImage } from "@/src/components/ResilientImage";
import {
  BRAND,
  DEFAULT_WHATSAPP_MESSAGE,
  HERO_METRICS,
  buildWhatsAppUrl,
} from "@/src/data/agencyData";

export function HeroSection() {
  const whatsappUrl = buildWhatsAppUrl(DEFAULT_WHATSAPP_MESSAGE);

  return (
    <section
      id="inicio"
      aria-labelledby="hero-heading"
      className="bg-gradient-hero border-b border-border overflow-x-clip"
    >
      <div className="mx-auto max-w-6xl px-4 pb-12 pt-10 sm:px-6 sm:pt-14 lg:px-8 lg:pb-16 lg:pt-20">
        {/* Bloco centralizado de textos acima da primeira imagem */}
        <div className="mx-auto flex max-w-3xl flex-col items-center text-center">
          <p className="text-xs sm:text-sm font-medium tracking-wide text-muted-foreground">
            Agência Digital{" "}
            <span aria-hidden="true" className="mx-1.5">
              ·
            </span>{" "}
            Pequenas Empresas e MEI{" "}
            <span aria-hidden="true" className="mx-1.5">
              ·
            </span>{" "}
            {BRAND.tagline}
          </p>

          <h1
            id="hero-heading"
            className="mt-5 font-display text-[clamp(2rem,5.2vw,3.75rem)] font-semibold leading-[1.1] tracking-tight text-foreground [text-wrap:balance]"
          >
            {BRAND.tagline}{" "}
            <span className="italic font-medium text-primary">
              Sites de alto padrão
            </span>{" "}
            que geram autoridade e clientes reais.
          </h1>

          <p className="mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            Transformamos a sua ideia em uma plataforma digital rápida,
            responsiva e estratégica para atrair clientes no Google e converter
            visitas em conversas no WhatsApp — com entrega em{" "}
            <strong className="font-semibold text-foreground">
              1 dia útil
            </strong>{" "}
            e atendimento humano do início ao fim.
          </p>

          <div className="mt-8 flex w-full flex-col items-center justify-center gap-3 sm:w-auto sm:flex-row">
            <Button
              asChild
              size="lg"
              className="h-auto min-h-12 w-full max-w-full whitespace-normal px-5 py-3 text-center sm:w-auto sm:whitespace-nowrap sm:px-7"
            >
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
              >
                <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>Solicitar análise e orçamento no WhatsApp</span>
              </a>
            </Button>

            <Button
              asChild
              variant="outline"
              size="lg"
              className="h-auto min-h-12 w-full max-w-full whitespace-normal px-5 py-3 text-center sm:w-auto sm:whitespace-nowrap sm:px-7"
            >
              <a href="#contato">
                <span>Enviar briefing rápido</span>
                <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
              </a>
            </Button>
          </div>

          <p className="mt-4 text-xs text-muted-foreground">
            Atendimento direto pelo {BRAND.whatsappDisplay}
            <span aria-hidden="true" className="mx-2">
              ·
            </span>
            Análise gratuita e sem compromisso
          </p>
        </div>

        {/* Primeira imagem em destaque 16:9 logo abaixo dos textos centralizados */}
        <div className="mx-auto mt-10 max-w-5xl sm:mt-12">
          <div className="relative aspect-[16/10] overflow-hidden rounded-xl border border-border bg-primary shadow-elevated sm:aspect-[16/9]">
            <ResilientImage
              src="/src/assets/images/hero_jgo_studio_1795666187402.jpg"
              alt="Ambiente refinado da agência JGO Studio com estação de trabalho exibindo um site institucional moderno em azul marinho e branco"
              fallbackTitle="JGO Studio"
            />
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 bg-gradient-media-scrim"
            />
            <div className="absolute inset-x-0 bottom-0 flex flex-col justify-between gap-2 p-5 text-primary-foreground sm:flex-row sm:items-end sm:p-6">
              <div>
                <p className="text-xs font-medium text-obsidian-muted">
                  Arquitetura Web &amp; Conversão
                </p>
                <p className="font-display text-base font-medium tracking-tight sm:text-lg">
                  Design pensado para pequenas empresas e MEI
                </p>
              </div>
              <span className="hidden text-xs font-medium text-obsidian-muted sm:inline whitespace-nowrap">
                {BRAND.instagramHandle}
              </span>
            </div>
          </div>
        </div>

        {/* Faixa horizontal de provas quantitativas */}
        <div className="mt-10 grid grid-cols-1 gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {HERO_METRICS.map((metric) => (
            <div
              key={metric.value}
              className="bg-card px-6 py-5 transition-colors duration-200 hover:bg-surface"
            >
              <p className="font-display text-2xl font-semibold tracking-tight text-primary tabular-nums sm:text-3xl">
                {metric.value}
              </p>
              <p className="mt-1 text-sm leading-snug text-muted-foreground">
                {metric.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
