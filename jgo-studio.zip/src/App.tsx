import { Toaster } from "@/src/components/ui/sonner";
import { Navbar } from "@/src/components/Navbar";
import { HeroSection } from "@/src/components/HeroSection";
import { AboutSection } from "@/src/components/AboutSection";
import { ServicesSection } from "@/src/components/ServicesSection";
import { PricingSection } from "@/src/components/PricingSection";
import { ContactSection } from "@/src/components/ContactSection";
import { Footer } from "@/src/components/Footer";
import { FloatingWhatsApp } from "@/src/components/FloatingWhatsApp";

export default function App() {
  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-primary selection:text-primary-foreground">
      <a
        href="#conteudo-principal"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-primary focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-primary-foreground"
      >
        Ir para o conteúdo principal
      </a>

      <Navbar />

      <main id="conteudo-principal">
        <HeroSection />
        <AboutSection />
        <ServicesSection />
        <PricingSection />
        <ContactSection />
      </main>

      <Footer />
      <FloatingWhatsApp />
      <Toaster position="bottom-left" />
    </div>
  );
}
